declare module "utif" {
  export interface IFD {
    width: number;
    height: number;
    data?: Uint8Array;
    t256?: number[];
    t257?: number[];
  }
  export function decode(buffer: ArrayBuffer | Uint8Array): IFD[];
  export function decodeImage(buffer: ArrayBuffer | Uint8Array, ifd: IFD): void;
  export function toRGBA8(ifd: IFD): Uint8Array;
}
