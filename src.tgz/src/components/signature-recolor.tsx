import { Crop, Pipette, RotateCcw, Signature, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Dropzone } from "@/components/dropzone";
import { GuardPanel, useProcessGuard } from "@/components/process-guard";
import { SavePngButton } from "@/components/save-png-button";
import { Button } from "@/components/ui/button";
import { COOLDOWN_MS, DEFAULT_SOURCE, DEFAULT_TARGET } from "@/lib/guard/constants";
import { cropToInk, type CropResult } from "@/lib/image/crop";
import {
  canvasHasTransparency,
  canvasToPngBlob,
  decodeImage,
} from "@/lib/image/decode";
import { detectDominantColor } from "@/lib/image/detect-color";
import { applyRecolor } from "@/lib/image/recolor";
import { sniffFile } from "@/lib/image/validate";

export function SignatureRecolor() {
  const guard = useProcessGuard("recolor");
  const [file, setFile] = useState<File | null>(null);
  const [fullCanvas, setFullCanvas] = useState<HTMLCanvasElement | null>(null);
  const [croppedCanvas, setCroppedCanvas] = useState<HTMLCanvasElement | null>(null);
  const [cropOn, setCropOn] = useState(true);
  const [cropMeta, setCropMeta] = useState<CropResult | null>(null);
  const [sourceHex, setSourceHex] = useState(DEFAULT_SOURCE);
  const [targetHex, setTargetHex] = useState(DEFAULT_TARGET);
  const [tolerance, setTolerance] = useState(62);
  const [originalUrl, setOriginalUrl] = useState<string | null>(null);
  const [liveUrl, setLiveUrl] = useState<string | null>(null);
  const [liveBlob, setLiveBlob] = useState<Blob | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [applied, setApplied] = useState(false);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [cooldown, setCooldown] = useState(0);
  const [sizeNote, setSizeNote] = useState<string | null>(null);

  const sourceCanvas = cropOn && croppedCanvas ? croppedCanvas : fullCanvas;

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = window.setInterval(() => setCooldown((c) => Math.max(0, c - 200)), 200);
    return () => window.clearInterval(t);
  }, [cooldown]);

  useEffect(() => {
    return () => {
      if (originalUrl) URL.revokeObjectURL(originalUrl);
      if (liveUrl) URL.revokeObjectURL(liveUrl);
    };
  }, [originalUrl, liveUrl]);

  const liveCanvas = useMemo(() => {
    if (!sourceCanvas) return null;
    try {
      return applyRecolor(sourceCanvas, sourceHex, targetHex, tolerance);
    } catch {
      return null;
    }
  }, [sourceCanvas, sourceHex, targetHex, tolerance]);

  useEffect(() => {
    if (!liveCanvas) {
      setLiveBlob(null);
      return;
    }
    let revoked = false;
    canvasToPngBlob(liveCanvas).then((blob) => {
      if (revoked) return;
      setLiveBlob(blob);
      const url = URL.createObjectURL(blob);
      setLiveUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return url;
      });
    });
    return () => {
      revoked = true;
    };
  }, [liveCanvas]);

  async function activate(canvas: HTMLCanvasElement) {
    const png = await canvasToPngBlob(canvas);
    setFile(new File([png], "signature.png", { type: "image/png" }));
    setOriginalUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(png);
    });
  }

  async function onFile(next: File) {
    setError(null);
    setApplied(false);
    setSizeNote(null);
    setCropMeta(null);
    const check = await sniffFile(next, "signature");
    if (!check.ok) {
      setError(check.message);
      toast.error(check.message);
      return;
    }
    try {
      const decoded = await decodeImage(next, check.format);
      if (!canvasHasTransparency(decoded.canvas)) {
        decoded.bitmap.close();
        const message = "That PNG is fully opaque. Signatures must have a transparent background.";
        setError(message);
        toast.error(message);
        return;
      }
      decoded.bitmap.close();

      const crop = cropToInk(decoded.canvas);
      setFullCanvas(decoded.canvas);
      setCroppedCanvas(crop.cropped ? crop.canvas : decoded.canvas);
      setCropOn(crop.cropped);
      setCropMeta(crop.cropped ? crop : null);

      const active = crop.cropped ? crop.canvas : decoded.canvas;
      await activate(active);

      const notes: string[] = [];
      if (decoded.resized) {
        notes.push(
          `Resized ${decoded.originalWidth}×${decoded.originalHeight} → ${decoded.width}×${decoded.height}`,
        );
      }
      if (crop.cropped) {
        notes.push(`Cropped ${crop.fromWidth}×${crop.fromHeight} → ${crop.toWidth}×${crop.toHeight}`);
        toast.success(`Empty space cropped · ${crop.toWidth}×${crop.toHeight}`);
      }
      setSizeNote(notes.length ? notes.join(" · ") : null);
      setSourceHex(DEFAULT_SOURCE);
      setTargetHex(DEFAULT_TARGET);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not read this PNG.";
      setError(message);
      toast.error(message);
    }
  }

  async function toggleCrop() {
    if (!fullCanvas || !cropMeta) return;
    const next = !cropOn;
    setCropOn(next);
    const canvas = next && croppedCanvas ? croppedCanvas : fullCanvas;
    await activate(canvas);
    toast.message(next ? "Cropped to ink" : "Showing full canvas");
  }

  function detect() {
    if (!sourceCanvas) return;
    const hex = detectDominantColor(sourceCanvas);
    setSourceHex(hex);
    toast.success(`Main ink color set to ${hex}`);
  }

  async function process() {
    if (!file || !sourceCanvas || !liveCanvas) return;
    if (!guard.verified) {
      const message = "Complete the human check before processing.";
      setError(message);
      toast.error(message);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const ticket = await guard.requestTicket({
        byteSize: file.size,
        width: sourceCanvas.width,
        height: sourceCanvas.height,
        mime: "image/png",
      });
      if (!ticket.ok) {
        setError(ticket.message);
        toast.error(ticket.message);
        setBusy(false);
        return;
      }
      setRemaining(ticket.remaining);
      setApplied(true);
      setCooldown(ticket.cooldownMs || COOLDOWN_MS);
      guard.reset();
      toast.success("Signature recolored. Save the PNG.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Recolor failed.";
      setError(message);
      toast.error(message);
    } finally {
      setBusy(false);
    }
  }

  function clear() {
    if (originalUrl) URL.revokeObjectURL(originalUrl);
    if (liveUrl) URL.revokeObjectURL(liveUrl);
    setFile(null);
    setFullCanvas(null);
    setCroppedCanvas(null);
    setCropOn(true);
    setCropMeta(null);
    setOriginalUrl(null);
    setLiveUrl(null);
    setLiveBlob(null);
    setApplied(false);
    setError(null);
    setSizeNote(null);
    setSourceHex(DEFAULT_SOURCE);
    setTargetHex(DEFAULT_TARGET);
  }

  return (
    <div className="space-y-5">
      <div className="space-y-1.5">
        <h2 className="flex items-center gap-2 text-lg font-medium tracking-tight">
          <Signature className="size-4 text-muted" />
          Signature color
        </h2>
        <p className="text-sm text-muted">
          Transparent PNG only. Empty space is cropped automatically. Default maps
          black ink to professional blue.
        </p>
      </div>

      {!applied && <GuardPanel {...guard} />}

      {!fullCanvas && (
        <Dropzone
          accept="image/png,.png"
          title="Drop a transparent PNG signature"
          hint="PNG with alpha · auto-crops empty space · max 10 MB"
          disabled={!guard.verified}
          disabledReason="Complete verification above to unlock upload."
          onFile={onFile}
        />
      )}

      {fullCanvas && sourceCanvas && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <figure className="space-y-2">
              <figcaption className="text-xs font-medium text-muted">Original</figcaption>
              <div className="checkerboard overflow-hidden rounded-2xl p-6">
                {originalUrl && (
                  <img
                    src={originalUrl}
                    alt="Original signature"
                    className="mx-auto max-h-48 w-auto"
                  />
                )}
              </div>
            </figure>
            <figure className="space-y-2">
              <figcaption className="text-xs font-medium text-muted">Live preview</figcaption>
              <div className="checkerboard overflow-hidden rounded-2xl p-6">
                {liveUrl && (
                  <img
                    src={liveUrl}
                    alt="Recolored signature"
                    className="mx-auto max-h-48 w-auto"
                  />
                )}
              </div>
            </figure>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <ColorField
              label="Source color"
              value={sourceHex}
              onChange={setSourceHex}
            />
            <ColorField
              label="Target color"
              value={targetHex}
              onChange={setTargetHex}
            />
          </div>

          <label className="block space-y-2">
            <span className="flex items-center justify-between text-xs font-medium text-muted">
              Match tolerance
              <span className="tabular-nums text-fg">{tolerance}</span>
            </span>
            <input
              type="range"
              min={10}
              max={100}
              value={tolerance}
              onChange={(e) => setTolerance(Number(e.target.value))}
              className="h-11 w-full accent-accent"
            />
          </label>

          {error && (
            <p className="rounded-xl bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>
          )}

          {(remaining !== null || sizeNote) && (
            <p className="text-xs tabular-nums text-muted">
              {sizeNote}
              {sizeNote && remaining !== null ? " · " : ""}
              {remaining !== null ? `${remaining} recolors left this hour` : ""}
            </p>
          )}

          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant={cropOn && cropMeta ? "secondary" : "ghost"}
              onClick={toggleCrop}
              disabled={!cropMeta}
              aria-pressed={cropOn}
            >
              <Crop className="size-4" />
              {cropOn && cropMeta ? "Cropped to ink" : "Auto-crop"}
            </Button>
            <Button type="button" variant="secondary" onClick={detect}>
              <Pipette className="size-4" />
              Detect main color
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setSourceHex(DEFAULT_SOURCE);
                setTargetHex(DEFAULT_TARGET);
                setTolerance(62);
              }}
            >
              <RotateCcw className="size-4" />
              Reset colors
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            {applied && liveBlob ? (
              <SavePngButton
                blob={liveBlob}
                filename="inkline-signature.png"
                previewUrl={liveUrl ?? undefined}
              />
            ) : (
              <Button
                type="button"
                onClick={process}
                disabled={busy || !guard.verified || cooldown > 0}
                className="min-h-11 min-w-40"
              >
                {busy
                  ? "Processing"
                  : cooldown > 0
                    ? `Wait ${(cooldown / 1000).toFixed(0)}s`
                    : "Apply recolor"}
              </Button>
            )}
            <Button type="button" variant="ghost" onClick={clear}>
              <X className="size-4" />
              {applied ? "New image" : "Clear"}
            </Button>
          </div>
        </div>
      )}

      {error && !fullCanvas && (
        <p className="rounded-xl bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>
      )}
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="flex items-center gap-3 rounded-2xl bg-surface-2/70 px-3 py-2">
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value.toUpperCase())}
        className="size-11 cursor-pointer rounded-lg border-0 bg-transparent p-0"
        aria-label={label}
      />
      <span className="min-w-0 flex-1">
        <span className="block text-xs font-medium text-muted">{label}</span>
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-transparent font-mono text-sm uppercase tracking-wide text-fg outline-none"
          spellCheck={false}
        />
      </span>
    </label>
  );
}
