import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";

export function ThemeToggle() {
  const { theme, toggle } = useTheme();
  const dark = theme === "dark";
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      onClick={toggle}
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
      className="relative"
    >
      <span className="relative size-4">
        <Sun
          className={
            "absolute inset-0 size-4 transition-[opacity,transform,filter] duration-300 " +
            (dark
              ? "scale-[0.25] opacity-0 blur-[4px]"
              : "scale-100 opacity-100 blur-none")
          }
        />
        <Moon
          className={
            "absolute inset-0 size-4 transition-[opacity,transform,filter] duration-300 " +
            (dark
              ? "scale-100 opacity-100 blur-none"
              : "scale-[0.25] opacity-0 blur-[4px]")
          }
        />
      </span>
    </Button>
  );
}
