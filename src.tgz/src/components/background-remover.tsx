import { Eraser, Loader2, X } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CompareSlider } from "@/components/compare-slider";
import { Dropzone } from "@/components/dropzone";
import { GuardPanel, useProcessGuard } from "@/components/process-guard";
import { ProgressBar } from "@/components/progress-bar";
import { SavePngButton } from "@/components/save-png-button";
import { Button } from "@/components/ui/button";
import { COOLDOWN_MS } from "@/lib/guard/constants";
import { canvasToBlob, decodeImage } from "@/lib/image/decode";
import { preloadBackgroundModel, removeBackgroundBlob } from "@/lib/image/remove-bg";
import { sniffFile } from "@/lib/image/validate";

type Stage = "idle" | "ready" | "working" | "done";

type Meta = {
  w: number;
  h: number;
  mime: string;
  originalW: number;
  originalH: number;
  resized: boolean;
};

export function BackgroundRemover() {
  const guard = useProcessGuard("bg-remove");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const [meta, setMeta] = useState<Meta | null>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [progress, setProgress] = useState(0);
  const [progressLabel, setProgressLabel] = useState("Working");
  const [error, setError] = useState<string | null>(null);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = window.setInterval(() => {
      setCooldown((c) => Math.max(0, c - 200));
    }, 200);
    return () => window.clearInterval(t);
  }, [cooldown]);

  useEffect(() => {
    if (!guard.verified) return;
    preloadBackgroundModel().catch(() => undefined);
  }, [guard.verified]);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
      if (result) URL.revokeObjectURL(result);
    };
  }, [preview, result]);

  async function onFile(next: File) {
    setError(null);
    setResult(null);
    setResultBlob(null);
    const check = await sniffFile(next, "photo");
    if (!check.ok) {
      setError(check.message);
      toast.error(check.message);
      return;
    }
    try {
      const decoded = await decodeImage(next, check.format);
      decoded.bitmap.close();
      const processBlob = await canvasToBlob(decoded.canvas, "image/jpeg", 0.92);
      const processFile = new File([processBlob], "photo.jpg", { type: "image/jpeg" });
      if (preview) URL.revokeObjectURL(preview);
      const url = URL.createObjectURL(processBlob);
      setFile(processFile);
      setPreview(url);
      setMeta({
        w: decoded.width,
        h: decoded.height,
        mime: "image/jpeg",
        originalW: decoded.originalWidth,
        originalH: decoded.originalHeight,
        resized: decoded.resized,
      });
      setStage("ready");
      if (decoded.resized) {
        toast.message(
          `Photo is ${decoded.originalWidth}×${decoded.originalHeight} — resized to ${decoded.width}×${decoded.height} for processing.`,
        );
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not read this image.";
      setError(message);
      toast.error(message);
    }
  }

  async function process() {
    if (!file || !meta) return;
    if (!guard.verified) {
      const message = "Complete the human check before processing.";
      setError(message);
      toast.error(message);
      return;
    }
    setError(null);
    setStage("working");
    setProgress(0.02);
    setProgressLabel("Checking limits");
    try {
      const ticket = await guard.requestTicket({
        byteSize: file.size,
        width: meta.w,
        height: meta.h,
        mime: meta.mime,
      });
      if (!ticket.ok) {
        setStage("ready");
        setError(ticket.message);
        toast.error(ticket.message);
        return;
      }
      setRemaining(ticket.remaining);
      setProgressLabel("Preparing model");
      const blob = await removeBackgroundBlob(file, (label, ratio) => {
        setProgressLabel(label);
        setProgress(Math.max(0.05, Math.min(0.98, ratio)));
      });
      const png =
        blob.type === "image/png"
          ? blob
          : new Blob([await blob.arrayBuffer()], { type: "image/png" });
      if (result) URL.revokeObjectURL(result);
      const url = URL.createObjectURL(png);
      setResult(url);
      setResultBlob(png);
      setStage("done");
      setProgress(1);
      setCooldown(ticket.cooldownMs || COOLDOWN_MS);
      guard.reset();
      toast.success("Background removed. Save the transparent PNG.");
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : "Background removal failed. Try a smaller image, or refresh and retry.";
      setError(message);
      setStage("ready");
      toast.error(message);
    }
  }

  function clear() {
    if (preview) URL.revokeObjectURL(preview);
    if (result) URL.revokeObjectURL(result);
    setFile(null);
    setPreview(null);
    setResult(null);
    setResultBlob(null);
    setMeta(null);
    setStage("idle");
    setError(null);
  }

  return (
    <div className="space-y-5">
      <div className="space-y-1.5">
        <h2 className="flex items-center gap-2 text-lg font-medium tracking-tight">
          <Eraser className="size-4 text-muted" />
          Background remover
        </h2>
        <p className="text-sm text-muted">
          Runs entirely in your browser. The first cut downloads a one-time on-device model.
        </p>
      </div>

      {stage !== "done" && <GuardPanel {...guard} />}

      {!preview && (
        <Dropzone
          accept="image/jpeg,image/jpg,image/png,image/webp,image/heic,image/heif,image/bmp,image/tiff,.jpg,.jpeg,.png,.webp,.heic,.heif,.bmp,.tif,.tiff"
          title="Drop a photo, or click to browse"
          hint="JPEG, PNG, WEBP, HEIC, BMP, TIFF · max 10 MB · large photos auto-resize"
          disabled={!guard.verified}
          disabledReason="Complete verification above to unlock upload."
          onFile={onFile}
        />
      )}

      {preview && (
        <div className="space-y-4">
          {result && preview ? (
            <CompareSlider beforeUrl={preview} afterUrl={result} afterLabel="Cutout" />
          ) : (
            <div className="overflow-hidden rounded-2xl bg-surface-2">
              <img
                src={preview}
                alt="Upload preview"
                className="mx-auto max-h-[420px] w-auto outline outline-1 -outline-offset-1 outline-fg/10"
              />
            </div>
          )}

          {result && (
            <figure className="space-y-2">
              <figcaption className="text-xs font-medium text-muted">
                Transparent PNG · on iPhone, tap Download or hold the image
              </figcaption>
              <div className="checkerboard overflow-hidden rounded-2xl p-4">
                <img
                  src={result}
                  alt="Transparent cutout"
                  className="mx-auto max-h-72 w-auto"
                />
              </div>
            </figure>
          )}

          {meta && (
            <p className="text-xs tabular-nums text-muted">
              {meta.resized
                ? `${meta.originalW}×${meta.originalH} → ${meta.w}×${meta.h} (resized)`
                : `${meta.w}×${meta.h}`}
              {file ? ` · ${(file.size / (1024 * 1024)).toFixed(2)} MB` : ""}
              {remaining !== null ? ` · ${remaining} jobs left this hour` : ""}
            </p>
          )}

          {stage === "working" && <ProgressBar value={progress} label={progressLabel} />}

          {error && (
            <p className="rounded-xl bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>
          )}

          <div className="flex flex-wrap gap-2">
            {resultBlob ? (
              <SavePngButton
                blob={resultBlob}
                filename="inkline-cutout.png"
                previewUrl={result ?? undefined}
              />
            ) : (
              <Button
                type="button"
                onClick={process}
                disabled={stage === "working" || !guard.verified || cooldown > 0}
                className="min-h-11 min-w-40"
              >
                {stage === "working" ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Processing
                  </>
                ) : cooldown > 0 ? (
                  `Wait ${(cooldown / 1000).toFixed(0)}s`
                ) : (
                  "Remove background"
                )}
              </Button>
            )}
            <Button type="button" variant="ghost" onClick={clear} aria-label="Clear image">
              <X className="size-4" />
              {stage === "done" ? "New image" : "Clear"}
            </Button>
          </div>
        </div>
      )}

      {error && !preview && (
        <p className="rounded-xl bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>
      )}
    </div>
  );
}
