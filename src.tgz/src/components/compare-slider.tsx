import { useCallback, useRef, useState } from "react";
import { cn } from "@/lib/cn";

type Props = {
  beforeUrl: string;
  afterUrl: string;
  beforeLabel?: string;
  afterLabel?: string;
  className?: string;
};

export function CompareSlider({
  beforeUrl,
  afterUrl,
  beforeLabel = "Original",
  afterLabel = "Result",
  className,
}: Props) {
  const wrap = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(52);
  const dragging = useRef(false);

  const move = useCallback((clientX: number) => {
    const el = wrap.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const next = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.min(96, Math.max(4, next)));
  }, []);

  return (
    <div
      ref={wrap}
      role="slider"
      aria-label="Compare original and result"
      aria-valuemin={4}
      aria-valuemax={96}
      aria-valuenow={Math.round(pos)}
      tabIndex={0}
      className={cn(
        "checkerboard relative overflow-hidden rounded-2xl select-none touch-none",
        className,
      )}
      onKeyDown={(e) => {
        if (e.key === "ArrowLeft") setPos((p) => Math.max(4, p - 4));
        if (e.key === "ArrowRight") setPos((p) => Math.min(96, p + 4));
      }}
      onPointerDown={(e) => {
        dragging.current = true;
        e.currentTarget.setPointerCapture(e.pointerId);
        move(e.clientX);
      }}
      onPointerMove={(e) => {
        if (dragging.current) move(e.clientX);
      }}
      onPointerUp={() => {
        dragging.current = false;
      }}
      onPointerCancel={() => {
        dragging.current = false;
      }}
    >
      <img
        src={afterUrl}
        alt={afterLabel}
        className="block h-auto w-full outline outline-1 -outline-offset-1 outline-fg/10"
        draggable={false}
      />
      <img
        src={beforeUrl}
        alt={beforeLabel}
        className="absolute inset-0 h-full w-full object-fill outline outline-1 -outline-offset-1 outline-fg/10"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
        draggable={false}
      />
      <div
        className="pointer-events-none absolute inset-y-0 z-10 w-px bg-fg"
        style={{ left: `${pos}%` }}
      >
        <div className="absolute top-1/2 left-1/2 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-fg text-bg shadow-lg">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden>
            <path
              d="M6 4 L2 9 L6 14"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M12 4 L16 9 L12 14"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
      <span className="pointer-events-none absolute top-3 left-3 rounded-full bg-bg/80 px-2.5 py-1 text-xs font-medium text-fg backdrop-blur-sm">
        {beforeLabel}
      </span>
      <span className="pointer-events-none absolute top-3 right-3 rounded-full bg-bg/80 px-2.5 py-1 text-xs font-medium text-fg backdrop-blur-sm">
        {afterLabel}
      </span>
    </div>
  );
}
