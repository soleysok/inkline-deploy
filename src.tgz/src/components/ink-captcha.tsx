import { Check, GripVertical } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/cn";
import { verifyCaptcha, type ChallengePayload } from "@/lib/guard/functions";

type Props = {
  challenge: ChallengePayload | null;
  resetKey: number;
  onSolved: (pick: string, pickMs: number, samples: number[]) => void;
  onChallenge: (challenge: ChallengePayload) => void;
};

export function InkCaptcha({ challenge, resetKey, onSolved, onChallenge }: Props) {
  const shownAt = useRef(performance.now());
  const track = useRef<HTMLDivElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const samples = useRef<number[]>([]);
  const dragging = useRef(false);
  const xRef = useRef(0);
  const [x, setX] = useState(8);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [scale, setScale] = useState(1);

  const cap = challenge?.captcha;

  useEffect(() => {
    shownAt.current = performance.now();
    samples.current = [];
    dragging.current = false;
    xRef.current = 8;
    setX(8);
    setBusy(false);
    setDone(false);
  }, [resetKey, challenge?.nonce]);

  useEffect(() => {
    const el = track.current;
    if (!el || !cap) return;
    const update = () => setScale(el.clientWidth / cap.width);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [cap, challenge?.nonce]);

  if (!cap || cap.kind !== "slider") {
    return <p className="px-1 text-xs text-muted">Preparing a human check…</p>;
  }

  const maxX = Math.max(1, cap.width - cap.pieceSize);

  function setOffset(next: number) {
    const clamped = Math.min(maxX, Math.max(0, next));
    xRef.current = clamped;
    setX(clamped);
    samples.current.push(Math.round(clamped));
    if (samples.current.length > 64) samples.current = samples.current.slice(-64);
  }

  function atImageX(clientX: number) {
    const el = track.current;
    if (!el || !cap) return;
    const rect = el.getBoundingClientRect();
    const local = (clientX - rect.left) / (scale || 1);
    setOffset(local - cap.pieceSize / 2);
  }

  function atBarX(clientX: number) {
    const el = bar.current;
    if (!el || !cap) return;
    const rect = el.getBoundingClientRect();
    const t = (clientX - rect.left - 24) / Math.max(1, rect.width - 48);
    setOffset(t * maxX);
  }

  async function submit(offset: number) {
    if (!challenge || busy || done) return;
    setBusy(true);
    const pickMs = Math.round(performance.now() - shownAt.current);
    try {
      const res = await verifyCaptcha({
        data: {
          nonce: challenge.nonce,
          issuedAt: challenge.issuedAt,
          difficulty: challenge.difficulty,
          sig: challenge.sig,
          pick: String(Math.round(offset)),
          pickMs,
          samples: samples.current,
        },
      });
      if (res.ok) {
        setDone(true);
        onSolved(String(Math.round(offset)), pickMs, samples.current);
        return;
      }
      toast.error(res.message);
      if (res.challenge && "nonce" in res.challenge) onChallenge(res.challenge);
      else {
        xRef.current = 8;
        setX(8);
      }
    } catch {
      toast.error("Verification failed. Try again.");
    } finally {
      setBusy(false);
    }
  }

  function endDrag() {
    if (!dragging.current) return;
    dragging.current = false;
    if (xRef.current < 18) {
      xRef.current = 8;
      setX(8);
      return;
    }
    void submit(xRef.current);
  }

  if (done) {
    return (
      <p className="flex items-center gap-2 px-1 text-xs text-muted">
        <Check className="size-3.5 text-success" />
        Puzzle check passed.
      </p>
    );
  }

  const pieceLeft = x * scale;
  const pieceTop = cap.pieceY * scale;
  const piecePx = cap.pieceSize * scale;
  const barMax = Math.max(0, (bar.current?.clientWidth ?? 280) - 48);
  const barX = Math.min(barMax, (x / maxX) * barMax);

  return (
    <div className="space-y-3">
      <div className="space-y-1 px-1">
        <p className="text-sm font-medium text-fg">Fit the highlighted piece into the dark slot</p>
        <p className="text-xs text-muted">
          Grab the raised tile on the left — or the handle below — and slide it into the gap.
        </p>
      </div>
      <div
        ref={track}
        className="relative cursor-grab overflow-hidden rounded-2xl bg-[#efe8dc] select-none touch-none active:cursor-grabbing"
        onPointerDown={(e) => {
          if (busy) return;
          dragging.current = true;
          e.currentTarget.setPointerCapture(e.pointerId);
          atImageX(e.clientX);
        }}
        onPointerMove={(e) => {
          if (dragging.current) atImageX(e.clientX);
        }}
        onPointerUp={endDrag}
        onPointerCancel={() => {
          dragging.current = false;
        }}
      >
        <img
          src={cap.image}
          alt="Puzzle with a dark missing slot"
          width={cap.width}
          height={cap.height}
          draggable={false}
          className="block h-auto w-full"
        />
        <img
          src={cap.piece}
          alt="Piece to drag"
          draggable={false}
          className="pointer-events-none absolute"
          style={{
            left: pieceLeft,
            top: pieceTop,
            width: piecePx,
            height: piecePx,
            filter:
              "drop-shadow(0 1px 0 rgba(255,255,255,.85)) drop-shadow(0 6px 14px rgba(15,15,15,.42))",
          }}
        />
      </div>
      <div
        ref={bar}
        className={cn(
          "relative flex h-14 cursor-grab items-center overflow-hidden rounded-2xl bg-surface elevation select-none touch-none active:cursor-grabbing",
        )}
        onPointerDown={(e) => {
          if (busy) return;
          dragging.current = true;
          e.currentTarget.setPointerCapture(e.pointerId);
          atBarX(e.clientX);
        }}
        onPointerMove={(e) => {
          if (dragging.current) atBarX(e.clientX);
        }}
        onPointerUp={endDrag}
        onPointerCancel={() => {
          dragging.current = false;
        }}
      >
        <div
          className="pointer-events-none absolute inset-y-0 left-0 bg-accent/12"
          style={{ width: Math.max(56, barX + 56) }}
        />
        <p className="pointer-events-none absolute inset-0 flex items-center justify-center pl-10 text-xs text-muted">
          {busy ? "Checking fit…" : "Slide handle to move the piece"}
        </p>
        <div
          className="pointer-events-none absolute top-1 left-1 flex h-12 items-center gap-1 rounded-xl bg-surface px-1.5 elevation"
          style={{ transform: `translateX(${barX}px)` }}
        >
          <GripVertical className="size-4 text-muted" />
          <img
            src={cap.piece}
            alt=""
            className="size-9 object-contain"
            draggable={false}
          />
        </div>
      </div>
    </div>
  );
}
