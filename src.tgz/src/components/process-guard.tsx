import { Shield } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { InkCaptcha } from "@/components/ink-captcha";
import { HONEYPOT_NAME } from "@/lib/guard/constants";
import {
  createChallenge,
  issueTicket,
  type ChallengePayload,
  type TicketResult,
} from "@/lib/guard/functions";
import { solvePow } from "@/lib/pow";

export type FileMeta = {
  byteSize: number;
  width: number;
  height: number;
  mime: string;
};

export function useProcessGuard(job: "bg-remove" | "recolor") {
  const [fallbackOk, setFallbackOk] = useState(false);
  const [pick, setPick] = useState<string | null>(null);
  const [pickMs, setPickMs] = useState(0);
  const [samples, setSamples] = useState<number[]>([]);
  const [honeypot, setHoneypot] = useState("");
  const [challenge, setChallenge] = useState<ChallengePayload | null>(null);
  const [resetKey, setResetKey] = useState(0);

  const verified = fallbackOk;

  useEffect(() => {
    let live = true;
    createChallenge()
      .then((res) => {
        if (!live) return;
        if ("nonce" in res) setChallenge(res);
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [resetKey, job]);

  const reset = useCallback(() => {
    setFallbackOk(false);
    setPick(null);
    setPickMs(0);
    setSamples([]);
    setResetKey((k) => k + 1);
  }, []);

  const requestTicket = useCallback(
    async (file: FileMeta): Promise<TicketResult> => {
      if (!challenge || !pick) {
        return {
          ok: false,
          code: "captcha",
          message: "Complete the human check before processing.",
        };
      }
      const counter = await solvePow(challenge.nonce, challenge.difficulty);
      return issueTicket({
        data: {
          job,
          honeypot,
          file,
          challenge: {
            nonce: challenge.nonce,
            issuedAt: challenge.issuedAt,
            difficulty: challenge.difficulty,
            sig: challenge.sig,
            counter,
            pick,
            pickMs,
            samples,
          },
        },
      });
    },
    [challenge, honeypot, job, pick, pickMs, samples],
  );

  return {
    fallbackOk,
    setFallbackOk,
    setPick,
    setPickMs,
    setSamples,
    honeypot,
    setHoneypot,
    resetKey,
    reset,
    requestTicket,
    verified,
    challenge,
    setChallenge,
  };
}

export function GuardPanel({
  setFallbackOk,
  setPick,
  setPickMs,
  setSamples,
  honeypot,
  setHoneypot,
  resetKey,
  verified,
  challenge,
  setChallenge,
}: ReturnType<typeof useProcessGuard>) {
  return (
    <div className="space-y-3 rounded-2xl bg-surface-2/70 p-3">
      <p className="flex items-center gap-2 px-1 text-xs font-medium text-muted">
        <Shield className="size-3.5" />
        Verify to upload and process
      </p>

      <div aria-hidden="true" className="hidden">
        <label>
          Company fax
          <input
            type="text"
            name={HONEYPOT_NAME}
            tabIndex={-1}
            autoComplete="off"
            value={honeypot}
            onChange={(e) => setHoneypot(e.target.value)}
          />
        </label>
      </div>

      {!verified && (
        <InkCaptcha
          challenge={challenge}
          resetKey={resetKey}
          onSolved={(id, ms, path) => {
            setPick(id);
            setPickMs(ms);
            setSamples(path);
            setFallbackOk(true);
          }}
          onChallenge={setChallenge}
        />
      )}

      {verified && (
        <p className="px-1 text-xs text-muted">Verified. Upload is unlocked.</p>
      )}
    </div>
  );
}
