import { Download, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { savePng } from "@/lib/image/save";

type Props = {
  blob: Blob;
  filename: string;
  previewUrl?: string;
  disabled?: boolean;
};

export function SavePngButton({ blob, filename, previewUrl, disabled }: Props) {
  const [busy, setBusy] = useState(false);

  return (
    <Button
      type="button"
      disabled={disabled || busy}
      className="min-h-11 min-w-40"
      onClick={async () => {
        setBusy(true);
        try {
          const mode = await savePng(blob, filename);
          if (mode === "downloaded") toast.success("PNG downloaded.");
          if (mode === "opened") toast.message("Opened the PNG — hold it to save to Photos.");
        } catch (err) {
          if (previewUrl) {
            toast.message("Hold the cutout image to save it to Photos.");
          } else {
            const message = err instanceof Error && err.message !== "HOLD_TO_SAVE"
              ? err.message
              : "Could not start the download. Hold the image to save it.";
            toast.error(message);
          }
        } finally {
          setBusy(false);
        }
      }}
    >
      {busy ? <Loader2 className="size-4 animate-spin" /> : <Download className="size-4" />}
      {busy ? "Saving" : "Download PNG"}
    </Button>
  );
}
