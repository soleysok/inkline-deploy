import { ThemeToggle } from "@/components/theme-toggle";
import { APP_NAME } from "@/lib/guard/constants";

export function SiteHeader() {
  return (
    <header className="flex items-center justify-between gap-4 px-1 py-5">
      <a href="/" className="group flex items-center gap-2.5">
        <span className="flex size-8 items-center justify-center rounded-lg bg-fg text-bg">
          <svg viewBox="0 0 24 24" className="size-4" aria-hidden>
            <rect x="10.2" y="3" width="3.6" height="18" rx="1.2" fill="currentColor" />
            <rect x="14.4" y="14.2" width="5.4" height="2.4" rx="0.8" className="fill-accent" />
          </svg>
        </span>
        <span className="font-serif text-xl tracking-tight text-fg">{APP_NAME}</span>
      </a>
      <ThemeToggle />
    </header>
  );
}
