import { ImagePlus, Lock, Upload } from "lucide-react";
import { useCallback, useId, useState, type DragEvent } from "react";
import { cn } from "@/lib/cn";

type Props = {
  accept: string;
  hint: string;
  title: string;
  disabled?: boolean;
  disabledReason?: string;
  onFile: (file: File) => void;
};

export function Dropzone({
  accept,
  hint,
  title,
  disabled,
  disabledReason,
  onFile,
}: Props) {
  const id = useId();
  const [over, setOver] = useState(false);

  const take = useCallback(
    (file?: File | null) => {
      if (disabled || !file) return;
      onFile(file);
    },
    [disabled, onFile],
  );

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setOver(false);
    take(e.dataTransfer.files?.[0]);
  };

  return (
    <label
      htmlFor={disabled ? undefined : id}
      onDragEnter={(e) => {
        e.preventDefault();
        if (!disabled) setOver(true);
      }}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={onDrop}
      className={cn(
        "group relative flex min-h-44 flex-col items-center justify-center gap-3 rounded-2xl border border-dashed px-5 py-8 text-center transition-[border-color,background-color,box-shadow,opacity] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]",
        disabled ? "cursor-not-allowed" : "cursor-pointer",
        over && !disabled
          ? "border-accent bg-accent/5 shadow-[0_0_0_4px_color-mix(in_oklab,var(--accent)_18%,transparent)]"
          : "border-border-strong bg-surface-2/50",
        !disabled && "hover:border-fg/30 hover:bg-surface-2",
      )}
    >
      <input
        id={id}
        type="file"
        accept={accept}
        disabled={disabled}
        className="sr-only"
        onChange={(e) => {
          take(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      <span className="flex size-11 items-center justify-center rounded-xl bg-surface elevation">
        {disabled ? (
          <Lock className="size-5 text-muted" />
        ) : over ? (
          <Upload className="size-5" />
        ) : (
          <ImagePlus className="size-5" />
        )}
      </span>
      <div className="space-y-1">
        <p className="text-sm font-medium text-fg">{title}</p>
        <p className="max-w-sm text-xs text-muted">
          {disabled ? disabledReason || hint : hint}
        </p>
      </div>
    </label>
  );
}
