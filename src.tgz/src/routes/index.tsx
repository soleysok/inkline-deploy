import * as Tabs from "@radix-ui/react-tabs";
import { createFileRoute } from "@tanstack/react-router";
import { Eraser, Lock, Signature, Sparkles } from "lucide-react";
import { useState } from "react";
import { BackgroundRemover } from "@/components/background-remover";
import { SignatureRecolor } from "@/components/signature-recolor";
import { SiteHeader } from "@/components/site-header";
import { JOB_LIMITS } from "@/lib/guard/constants";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [tab, setTab] = useState("cut");

  return (
    <div className="mx-auto flex min-h-dvh max-w-3xl flex-col px-4 pb-16 sm:px-6">
      <SiteHeader />

      <main className="flex flex-1 flex-col gap-8 pt-4 sm:pt-8">
        <section className="space-y-4">
          <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">
            Studio tools
          </p>
          <h1 className="font-serif text-4xl leading-[1.1] tracking-tight text-fg sm:text-5xl">
            Cut the background.
            <br />
            Recolor the ink.
          </h1>
          <p className="max-w-xl text-base text-muted">
            Two precise tools that run on-device. Photos never leave this tab.
            Abuse protection keeps the public studio usable.
          </p>
          <ul className="flex flex-wrap gap-2 pt-1">
            <Pill icon={Lock} label="Private by design" />
            <Pill icon={Sparkles} label="On-device AI" />
            <Pill icon={Eraser} label={`${JOB_LIMITS["bg-remove"]} cuts / hour`} />
            <Pill icon={Signature} label={`${JOB_LIMITS.recolor} recolors / hour`} />
          </ul>
        </section>

        <Tabs.Root value={tab} onValueChange={setTab} className="space-y-4">
          <Tabs.List className="relative grid grid-cols-2 gap-1 rounded-2xl bg-surface-2 p-1">
            <Tabs.Trigger
              value="cut"
              className="flex h-11 items-center justify-center gap-2 rounded-xl text-sm font-medium text-muted transition-colors duration-200 data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=active]:elevation"
            >
              <Eraser className="size-4" />
              Background
            </Tabs.Trigger>
            <Tabs.Trigger
              value="sign"
              className="flex h-11 items-center justify-center gap-2 rounded-xl text-sm font-medium text-muted transition-colors duration-200 data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=active]:elevation"
            >
              <Signature className="size-4" />
              Signature
            </Tabs.Trigger>
          </Tabs.List>

          <Tabs.Content
            value="cut"
            className="rounded-3xl bg-surface p-4 elevation data-[state=inactive]:hidden sm:p-6"
          >
            <BackgroundRemover />
          </Tabs.Content>
          <Tabs.Content
            value="sign"
            className="rounded-3xl bg-surface p-4 elevation data-[state=inactive]:hidden sm:p-6"
          >
            <SignatureRecolor />
          </Tabs.Content>
        </Tabs.Root>
      </main>

      <footer className="mt-12 space-y-2 border-t border-border pt-6 text-xs text-subtle">
        <p>
          Processing happens in your browser. The server only issues a short-lived
          ticket after Inkline’s built-in puzzle captcha, then enforces per-IP hourly
          limits and a brief cooldown.
        </p>
        <p>10 MB · JPEG PNG WEBP HEIC BMP TIFF · signatures PNG only · large photos auto-resize to 4000px.</p>
      </footer>
    </div>
  );
}

function Pill({
  icon: Icon,
  label,
}: {
  icon: typeof Lock;
  label: string;
}) {
  return (
    <li className="inline-flex h-9 items-center justify-center gap-1.5 rounded-full bg-surface px-3 text-xs font-medium text-fg elevation">
      <Icon className="size-3.5 text-muted" />
      {label}
    </li>
  );
}
