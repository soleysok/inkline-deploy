export async function solvePow(nonce: string, difficulty: number): Promise<number> {
  const enc = new TextEncoder();
  let counter = 0;
  while (true) {
    const digest = await crypto.subtle.digest("SHA-256", enc.encode(`${nonce}:${counter}`));
    const hex = [...new Uint8Array(digest)]
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
    let zeros = 0;
    for (const ch of hex) {
      if (ch === "0") zeros += 1;
      else break;
    }
    if (zeros >= difficulty) return counter;
    counter += 1;
    if (counter > 5_000_000) throw new Error("Verification timed out.");
  }
}
