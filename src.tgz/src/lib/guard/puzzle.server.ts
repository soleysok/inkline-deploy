import { PNG } from "pngjs";

export const PUZZLE_W = 304;
export const PUZZLE_H = 168;
export const PIECE = 56;
export const SLIDER_TOL = 5;
const NUB = 11;

export type PuzzlePublic = {
  kind: "slider";
  image: string;
  piece: string;
  width: number;
  height: number;
  pieceSize: number;
  pieceY: number;
};

type Rgba = [number, number, number, number];

function setPx(data: Uint8Array, w: number, x: number, y: number, [r, g, b, a]: Rgba) {
  if (x < 0 || y < 0 || x >= w || y >= data.length / (w * 4)) return;
  const i = (y * w + x) * 4;
  const da = a / 255;
  const ia = 1 - da;
  data[i] = Math.round((data[i] ?? 0) * ia + r * da);
  data[i + 1] = Math.round((data[i + 1] ?? 0) * ia + g * da);
  data[i + 2] = Math.round((data[i + 2] ?? 0) * ia + b * da);
  data[i + 3] = 255;
}

function getPx(data: Uint8Array, w: number, x: number, y: number): Rgba {
  const i = (y * w + x) * 4;
  return [data[i] ?? 0, data[i + 1] ?? 0, data[i + 2] ?? 0, data[i + 3] ?? 0];
}

function inPiece(lx: number, ly: number): boolean {
  const body = lx >= 0 && lx < PIECE - NUB && ly >= 0 && ly < PIECE;
  const nub = Math.hypot(lx - (PIECE - NUB), ly - PIECE / 2) <= NUB;
  const notch = Math.hypot(lx - NUB, ly - PIECE / 2) <= NUB - 1.4;
  return (body || nub) && !notch;
}

function isEdge(lx: number, ly: number): boolean {
  if (!inPiece(lx, ly)) return false;
  return (
    !inPiece(lx - 1, ly) ||
    !inPiece(lx + 1, ly) ||
    !inPiece(lx, ly - 1) ||
    !inPiece(lx, ly + 1)
  );
}

function stamp(data: Uint8Array, w: number, h: number, x: number, y: number, radius: number, color: Rgba) {
  const r = Math.ceil(radius);
  for (let oy = -r; oy <= r; oy++) {
    for (let ox = -r; ox <= r; ox++) {
      const d = Math.hypot(ox, oy);
      if (d > radius) continue;
      const a = Math.max(0, 1 - d / radius);
      const px = Math.round(x + ox);
      const py = Math.round(y + oy);
      if (px < 0 || py < 0 || px >= w || py >= h) continue;
      setPx(data, w, px, py, [color[0], color[1], color[2], Math.round(color[3] * a * a)]);
    }
  }
}

function bezier(
  data: Uint8Array,
  w: number,
  h: number,
  p0: [number, number],
  p1: [number, number],
  p2: [number, number],
  p3: [number, number],
  radius: number,
  color: Rgba,
) {
  const steps = 64;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const u = 1 - t;
    const x =
      u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0];
    const y =
      u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1];
    stamp(data, w, h, x, y, radius, color);
  }
}

function toDataUrl(width: number, height: number, data: Uint8Array): string {
  const png = new PNG({ width, height });
  png.data.set(data);
  const buf = PNG.sync.write(png, { colorType: 6 });
  return `data:image/png;base64,${buf.toString("base64")}`;
}

export function generatePuzzle(rand: () => number): { targetX: number; public: PuzzlePublic } {
  const w = PUZZLE_W;
  const h = PUZZLE_H;
  const data = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const grain = (rand() - 0.5) * 12;
      const paper = 238 + grain;
      setPx(data, w, x, y, [paper, paper - 5, paper - 12, 255]);
    }
  }

  const targetX = 72 + Math.floor(rand() * (w - PIECE - 88));
  const targetY = 20 + Math.floor(rand() * (h - PIECE - 40));
  const cx = targetX + PIECE / 2;
  const cy = targetY + PIECE / 2;

  const ink: Rgba = [37, 99, 235, 230];
  const carbon: Rgba = [28, 25, 23, 200];
  const rust: Rgba = [120, 72, 48, 110];

  for (let s = 0; s < 3; s++) {
    const color = s === 0 ? ink : s === 1 ? carbon : rust;
    bezier(
      data,
      w,
      h,
      [16 + rand() * 30, 24 + rand() * (h - 50)],
      [90 + rand() * 70, rand() * h],
      [170 + rand() * 70, rand() * h],
      [250 + rand() * 40, 24 + rand() * (h - 48)],
      2.4 + rand() * 2.2,
      color,
    );
  }

  // Guaranteed ink through the tile so the piece is never blank paper.
  bezier(
    data,
    w,
    h,
    [cx - 80, cy + (rand() - 0.5) * 30],
    [cx - 20, cy - 18],
    [cx + 18, cy + 22],
    [cx + 90, cy + (rand() - 0.5) * 24],
    3.4,
    ink,
  );
  bezier(
    data,
    w,
    h,
    [cx - 70, cy + 16],
    [cx - 10, cy + 8],
    [cx + 12, cy - 14],
    [cx + 78, cy - 8],
    2.6,
    carbon,
  );

  for (let i = 0; i < 10; i++) {
    stamp(data, w, h, cx + (rand() - 0.5) * 36, cy + (rand() - 0.5) * 36, 1.2 + rand() * 1.8, ink);
  }

  const pieceData = new Uint8Array(PIECE * PIECE * 4);
  for (let ly = 0; ly < PIECE; ly++) {
    for (let lx = 0; lx < PIECE; lx++) {
      const i = (ly * PIECE + lx) * 4;
      if (!inPiece(lx, ly)) {
        pieceData[i + 3] = 0;
        continue;
      }
      const [r, g, b] = getPx(data, w, targetX + lx, targetY + ly);
      pieceData[i] = r;
      pieceData[i + 1] = g;
      pieceData[i + 2] = b;
      pieceData[i + 3] = 255;
    }
  }

  // Crisp outline so the tile reads as an object, even on paper.
  for (let ly = 0; ly < PIECE; ly++) {
    for (let lx = 0; lx < PIECE; lx++) {
      if (!isEdge(lx, ly)) continue;
      const i = (ly * PIECE + lx) * 4;
      const outer = lx + ly < 6 || lx < 2 || ly < 2;
      pieceData[i] = outer ? 255 : 22;
      pieceData[i + 1] = outer ? 255 : 22;
      pieceData[i + 2] = outer ? 252 : 20;
      pieceData[i + 3] = 255;
    }
  }
  for (let ly = 1; ly < PIECE - 1; ly++) {
    for (let lx = 1; lx < PIECE - 1; lx++) {
      if (!inPiece(lx, ly) || isEdge(lx, ly)) continue;
      if (
        isEdge(lx - 1, ly) ||
        isEdge(lx + 1, ly) ||
        isEdge(lx, ly - 1) ||
        isEdge(lx, ly + 1)
      ) {
        const i = (ly * PIECE + lx) * 4;
        pieceData[i] = Math.min(255, (pieceData[i] ?? 0) + 28);
        pieceData[i + 1] = Math.min(255, (pieceData[i + 1] ?? 0) + 28);
        pieceData[i + 2] = Math.min(255, (pieceData[i + 2] ?? 0) + 22);
      }
    }
  }

  // Recessed slot: keep texture, darken, draw a rim.
  for (let ly = 0; ly < PIECE; ly++) {
    for (let lx = 0; lx < PIECE; lx++) {
      if (!inPiece(lx, ly)) continue;
      const px = targetX + lx;
      const py = targetY + ly;
      const [r, g, b] = getPx(data, w, px, py);
      const edge = isEdge(lx, ly);
      const k = edge ? 0.18 : 0.38;
      setPx(data, w, px, py, [
        Math.round(r * k + 18),
        Math.round(g * k + 18),
        Math.round(b * k + 22),
        255,
      ]);
    }
  }

  return {
    targetX,
    public: {
      kind: "slider",
      image: toDataUrl(w, h, data),
      piece: toDataUrl(PIECE, PIECE, pieceData),
      width: w,
      height: h,
      pieceSize: PIECE,
      pieceY: targetY,
    },
  };
}

export function sliderMatches(
  claimedX: number,
  targetProbe: (x: number) => boolean,
): boolean {
  const x = Math.round(claimedX);
  for (let d = -SLIDER_TOL; d <= SLIDER_TOL; d++) {
    if (targetProbe(x + d)) return true;
  }
  return false;
}
