import { createServerFn } from "@tanstack/react-start";
import { getRequest, setResponseStatus } from "@tanstack/react-start/server";
import { z } from "zod";
import { pathLooksHuman, type CaptchaPublic } from "./captcha";
import {
  COOLDOWN_MS,
  JOB_LIMITS,
  MAX_DIMENSION,
  MAX_FILE_BYTES,
  PICK_MIN_MS,
  POW_DIFFICULTY,
  TICKET_TTL_MS,
  type JobType,
} from "./constants";

const jobSchema = z.enum(["bg-remove", "recolor"]);

const fileMetaSchema = z.object({
  byteSize: z.number().int().positive().max(MAX_FILE_BYTES),
  width: z.number().int().positive().max(MAX_DIMENSION),
  height: z.number().int().positive().max(MAX_DIMENSION),
  mime: z.string().min(3).max(80),
});

export type TicketOk = {
  ok: true;
  ticket: string;
  remaining: number;
  limit: number;
  cooldownMs: number;
};

export type TicketErr = {
  ok: false;
  code: "rate_limit" | "captcha" | "bot" | "cooldown" | "invalid";
  message: string;
  retryAfterMs?: number;
  remaining?: number;
  limit?: number;
};

export type TicketResult = TicketOk | TicketErr;

export type ChallengePayload = {
  nonce: string;
  issuedAt: number;
  difficulty: number;
  sig: string;
  captcha: CaptchaPublic;
};

const captchaFields = z.object({
  nonce: z.string().min(8).max(80),
  issuedAt: z.number().int().positive(),
  difficulty: z.number().int().min(1).max(8),
  sig: z.string().min(16).max(128),
  pick: z.string().min(1).max(40),
  pickMs: z.number().int().nonnegative(),
  samples: z.array(z.number().int()).max(80).optional(),
});

const ticketChallenge = captchaFields.extend({
  counter: z.number().int().nonnegative(),
});

async function mintChallenge(): Promise<ChallengePayload> {
  const { hmacSign, randomNonce } = await import("./hmac.server");
  const { randomInt } = await import("node:crypto");
  const { generatePuzzle } = await import("./puzzle.server");
  const nonce = randomNonce();
  const issuedAt = Date.now();
  const puzzle = generatePuzzle(() => randomInt(1_000_000_000) / 1_000_000_000);
  const payload = `${nonce}.${issuedAt}.${POW_DIFFICULTY}.${puzzle.targetX}`;
  return {
    nonce,
    issuedAt,
    difficulty: POW_DIFFICULTY,
    sig: hmacSign(payload),
    captcha: puzzle.public,
  };
}

export const createChallenge = createServerFn({ method: "POST" }).handler(
  async (): Promise<ChallengePayload | TicketErr> => {
    const { botCheck } = await import("./bot-check.server");
    const request = getRequest();
    const blocked = botCheck(request);
    if (blocked) {
      return { ok: false, code: "bot", message: blocked };
    }
    return mintChallenge();
  },
);

export type CaptchaCheck =
  | { ok: true }
  | { ok: false; message: string; challenge?: ChallengePayload };

export const verifyCaptcha = createServerFn({ method: "POST" })
  .validator(captchaFields)
  .handler(async ({ data }): Promise<CaptchaCheck> => {
    const { botCheck } = await import("./bot-check.server");
    const { hmacVerify } = await import("./hmac.server");
    const { rememberNonce } = await import("./rate-limit.server");
    const { sliderMatches } = await import("./puzzle.server");
    const request = getRequest();
    const blocked = botCheck(request);
    if (blocked) return { ok: false, message: blocked };

    if (Date.now() - data.issuedAt > TICKET_TTL_MS) {
      return { ok: false, message: "Verification expired. Try a new puzzle.", challenge: await mintChallenge() };
    }
    if (data.pickMs < PICK_MIN_MS || !pathLooksHuman(data.samples, data.pickMs)) {
      await rememberNonce(data.nonce, data.issuedAt + TICKET_TTL_MS);
      return { ok: false, message: "That slide didn’t look human. New puzzle.", challenge: await mintChallenge() };
    }
    const claimed = Number.parseInt(data.pick, 10);
    const ok =
      Number.isFinite(claimed) &&
      sliderMatches(claimed, (x) =>
        hmacVerify(`${data.nonce}.${data.issuedAt}.${data.difficulty}.${x}`, data.sig),
      );
    if (!ok) {
      await rememberNonce(data.nonce, data.issuedAt + TICKET_TTL_MS);
      return { ok: false, message: "Not quite — the piece must sit in the gap.", challenge: await mintChallenge() };
    }
    return { ok: true };
  });

const issueSchema = z.object({
  job: jobSchema,
  honeypot: z.string().max(200).optional(),
  file: fileMetaSchema,
  challenge: ticketChallenge,
});

export const issueTicket = createServerFn({ method: "POST" })
  .validator(issueSchema)
  .handler(async ({ data }): Promise<TicketResult> => {
    const { getClientIp, botCheck } = await import("./bot-check.server");
    const { hmacSign, hmacVerify, hashIp, sha256Hex, leadingZeroNibbles } =
      await import("./hmac.server");
    const { consumeSlot, rememberNonce, inspectLimits } = await import(
      "./rate-limit.server"
    );
    const { sliderMatches } = await import("./puzzle.server");

    const request = getRequest();
    const bot = botCheck(request);
    if (bot) {
      return { ok: false, code: "bot", message: bot };
    }

    if (data.honeypot && data.honeypot.length > 0) {
      return { ok: false, code: "bot", message: "Request rejected." };
    }

    const job = data.job as JobType;
    const ip = getClientIp(request);
    const ipHash = hashIp(ip);

    const snapshot = await inspectLimits(ipHash, job);
    if (snapshot.remaining <= 0) {
      setResponseStatus(429);
      return {
        ok: false,
        code: "rate_limit",
        message: friendlyRetry(snapshot.retryAfterMs, job),
        retryAfterMs: snapshot.retryAfterMs,
        remaining: 0,
        limit: snapshot.limit,
      };
    }
    if (snapshot.cooldownMs > 0) {
      setResponseStatus(429);
      return {
        ok: false,
        code: "cooldown",
        message: "Please wait a few seconds before the next job.",
        retryAfterMs: snapshot.cooldownMs,
        remaining: snapshot.remaining,
        limit: snapshot.limit,
      };
    }

    const ch = data.challenge;
    if (Date.now() - ch.issuedAt > TICKET_TTL_MS) {
      return {
        ok: false,
        code: "captcha",
        message: "Verification expired. Please try again.",
      };
    }
    if (ch.pickMs < PICK_MIN_MS || !pathLooksHuman(ch.samples, ch.pickMs)) {
      await rememberNonce(ch.nonce, ch.issuedAt + TICKET_TTL_MS);
      return {
        ok: false,
        code: "captcha",
        message: "Verification failed. Slide the piece into the gap.",
      };
    }
    const claimed = Number.parseInt(ch.pick, 10);
    const matched =
      Number.isFinite(claimed) &&
      sliderMatches(claimed, (x) =>
        hmacVerify(`${ch.nonce}.${ch.issuedAt}.${ch.difficulty}.${x}`, ch.sig),
      );
    if (!matched) {
      await rememberNonce(ch.nonce, ch.issuedAt + TICKET_TTL_MS);
      return { ok: false, code: "captcha", message: "Verification failed." };
    }
    const digest = sha256Hex(`${ch.nonce}:${ch.counter}`);
    if (leadingZeroNibbles(digest) < ch.difficulty) {
      return { ok: false, code: "captcha", message: "Verification failed." };
    }
    const stored = await rememberNonce(ch.nonce, ch.issuedAt + TICKET_TTL_MS);
    if (!stored) {
      return {
        ok: false,
        code: "captcha",
        message: "Verification already used. Please retry.",
      };
    }

    const consumed = await consumeSlot(ipHash, job);
    if ("blocked" in consumed) {
      const code = consumed.snapshot.remaining <= 0 ? "rate_limit" : "cooldown";
      setResponseStatus(429);
      return {
        ok: false,
        code,
        message:
          code === "rate_limit"
            ? friendlyRetry(consumed.snapshot.retryAfterMs, job)
            : "Please wait a few seconds before the next job.",
        retryAfterMs: consumed.snapshot.retryAfterMs,
        remaining: consumed.snapshot.remaining,
        limit: consumed.snapshot.limit,
      };
    }

    const issuedAt = Date.now();
    const ticketPayload = `${ipHash}.${job}.${issuedAt}.${data.file.byteSize}`;
    const ticket = `${issuedAt}.${hmacSign(ticketPayload)}`;

    return {
      ok: true,
      ticket,
      remaining: consumed.remaining,
      limit: consumed.limit,
      cooldownMs: COOLDOWN_MS,
    };
  });

function friendlyRetry(ms: number, job: JobType): string {
  const minutes = Math.max(1, Math.ceil(ms / 60000));
  const noun = job === "bg-remove" ? "background removals" : "signature recolors";
  return `Too many requests. You can run ${JOB_LIMITS[job]} ${noun} per hour. Try again in ${minutes} minute${minutes === 1 ? "" : "s"}.`;
}
