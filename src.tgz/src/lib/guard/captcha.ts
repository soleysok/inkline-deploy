export type CaptchaPublic = {
  kind: "slider";
  image: string;
  piece: string;
  width: number;
  height: number;
  pieceSize: number;
  pieceY: number;
};

export function pathLooksHuman(samples: number[] | undefined, pickMs: number): boolean {
  if (pickMs < 380) return false;
  if (!samples || samples.length < 5) return pickMs >= 900;
  const start = samples[0] ?? 0;
  const end = samples[samples.length - 1] ?? 0;
  if (Math.abs(end - start) < 18) return false;
  let jumps = 0;
  for (let i = 1; i < samples.length; i++) {
    const a = samples[i - 1] ?? 0;
    const b = samples[i] ?? 0;
    if (Math.abs(b - a) > 90) jumps += 1;
  }
  return jumps <= 2;
}
