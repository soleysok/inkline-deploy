import {
  createHmac,
  createHash,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";

function guardSecret(): string {
  return (
    process.env.GUARD_SECRET ||
    process.env.BETTER_AUTH_SECRET ||
    "inkline-preview-guard-v1"
  );
}

export function hmacSign(payload: string): string {
  return createHmac("sha256", guardSecret()).update(payload).digest("hex");
}

export function hmacVerify(payload: string, signature: string): boolean {
  const expected = hmacSign(payload);
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export function hashIp(ip: string): string {
  return createHmac("sha256", guardSecret()).update(ip).digest("hex").slice(0, 24);
}

export function sha256Hex(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

export function randomNonce(): string {
  return randomBytes(16).toString("hex");
}

export function leadingZeroNibbles(hex: string): number {
  let n = 0;
  for (const ch of hex) {
    if (ch === "0") n += 1;
    else break;
  }
  return n;
}
