export const APP_NAME = "Inkline";
export const APP_TAGLINE = "Cut backgrounds. Recolor signatures. Private by design.";

export const MAX_FILE_BYTES = 10 * 1024 * 1024;
/** Longest side we actually process. Larger photos are downscaled to this. */
export const MAX_DIMENSION = 4000;
/** Reject only pathological images that would blow browser memory. */
export const HARD_MAX_SIDE = 16000;
export const HARD_MAX_PIXELS = 80_000_000;
export const COOLDOWN_MS = 6_000;
export const HOUR_MS = 60 * 60 * 1000;

export const JOB_LIMITS = {
  "bg-remove": 10,
  recolor: 20,
} as const;

export type JobType = keyof typeof JOB_LIMITS;

export const BG_MIME = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "image/heic",
  "image/heif",
  "image/bmp",
  "image/x-bmp",
  "image/tiff",
  "image/tif",
]);

export const BG_EXT = new Set([
  "jpg",
  "jpeg",
  "png",
  "webp",
  "heic",
  "heif",
  "bmp",
  "tif",
  "tiff",
]);

export const SIGNATURE_MIME = new Set(["image/png"]);
export const SIGNATURE_EXT = new Set(["png"]);

export const DEFAULT_SOURCE = "#000000";
export const DEFAULT_TARGET = "#2563EB";

export const POW_DIFFICULTY = 4;
export const PICK_MIN_MS = 400;
export const TICKET_TTL_MS = 2 * 60 * 1000;

export const HONEYPOT_NAME = "company_fax";
