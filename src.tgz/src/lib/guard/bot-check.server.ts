const BOT_UA =
  /(?:bot|crawler|spider|crawling|curl|wget|python-requests|python-urllib|go-http-client|libwww|httpie|scrapy|phantomjs|headlesschrome|playwright|puppeteer)/i;

const BROWSER_HINT = /mozilla|chrome|safari|firefox|edg|applewebkit|opr\//i;

export function getClientIp(request: Request): string {
  const cf = request.headers.get("cf-connecting-ip");
  if (cf) return cf.trim();
  const real = request.headers.get("x-real-ip");
  if (real) return real.trim();
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]?.trim() || "0.0.0.0";
  return "0.0.0.0";
}

export function botCheck(request: Request): string | null {
  const ua = request.headers.get("user-agent") ?? "";
  if (!ua.trim()) return "Missing client identity.";
  if (BOT_UA.test(ua) && !BROWSER_HINT.test(ua)) {
    return "Automated clients are not allowed.";
  }
  if (!BROWSER_HINT.test(ua) && ua.length < 20) {
    return "Automated clients are not allowed.";
  }

  const site = request.headers.get("sec-fetch-site");
  if (site === "cross-site") return "Cross-site requests are blocked.";

  const dest = request.headers.get("sec-fetch-dest");
  if (dest === "document" || dest === "iframe" || dest === "embed") {
    return "Invalid request.";
  }

  return null;
}
