import { getSql } from "@/lib/db";
import {
  COOLDOWN_MS,
  HOUR_MS,
  JOB_LIMITS,
  TICKET_TTL_MS,
  type JobType,
} from "./constants";

type WindowRow = {
  count: number;
  last_success_at: number | null;
};

type CoolRow = { last_success_at: number };

export type LimitSnapshot = {
  remaining: number;
  limit: number;
  retryAfterMs: number;
  cooldownMs: number;
};

export async function inspectLimits(
  ipHash: string,
  job: JobType,
): Promise<LimitSnapshot> {
  const limit = JOB_LIMITS[job];
  const windowStart = Math.floor(Date.now() / HOUR_MS) * HOUR_MS;
  const sql = await getSql();

  const rows = await sql<WindowRow>`
    select count, last_success_at
    from rate_windows
    where ip_hash = ${ipHash} and job_type = ${job} and window_start = ${windowStart}
  `;
  const count = rows[0]?.count ?? 0;

  const cool = await sql<CoolRow>`
    select last_success_at from ip_cooldown where ip_hash = ${ipHash}
  `;
  const last = cool[0]?.last_success_at ?? 0;
  const since = Date.now() - last;
  const cooldownMs = last && since < COOLDOWN_MS ? COOLDOWN_MS - since : 0;

  const remaining = Math.max(0, limit - count);
  const retryAfterMs = remaining === 0 ? windowStart + HOUR_MS - Date.now() : cooldownMs;

  return { remaining, limit, retryAfterMs, cooldownMs };
}

export async function consumeSlot(
  ipHash: string,
  job: JobType,
): Promise<LimitSnapshot | { blocked: true; snapshot: LimitSnapshot }> {
  const snapshot = await inspectLimits(ipHash, job);
  if (snapshot.remaining <= 0) {
    return { blocked: true, snapshot };
  }
  if (snapshot.cooldownMs > 0) {
    return { blocked: true, snapshot };
  }

  const windowStart = Math.floor(Date.now() / HOUR_MS) * HOUR_MS;
  const sql = await getSql();
  const now = Date.now();

  await sql`
    insert into rate_windows (ip_hash, job_type, window_start, count, last_success_at)
    values (${ipHash}, ${job}, ${windowStart}, 1, ${now})
    on conflict (ip_hash, job_type, window_start)
    do update set count = rate_windows.count + 1, last_success_at = ${now}
  `;
  await sql`
    insert into ip_cooldown (ip_hash, last_success_at)
    values (${ipHash}, ${now})
    on conflict (ip_hash)
    do update set last_success_at = ${now}
  `;

  return {
    remaining: snapshot.remaining - 1,
    limit: snapshot.limit,
    retryAfterMs: COOLDOWN_MS,
    cooldownMs: COOLDOWN_MS,
  };
}

export async function rememberNonce(nonce: string, expiresAt: number): Promise<boolean> {
  const sql = await getSql();
  const now = Date.now();
  await sql`delete from used_nonces where expires_at < ${now}`;
  try {
    await sql`insert into used_nonces (nonce, expires_at) values (${nonce}, ${expiresAt})`;
    return true;
  } catch {
    return false;
  }
}

export async function isNonceUsed(nonce: string): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ nonce: string }>`
    select nonce from used_nonces where nonce = ${nonce}
  `;
  return rows.length > 0;
}

export { TICKET_TTL_MS };
