import {
  BG_EXT,
  BG_MIME,
  HARD_MAX_PIXELS,
  HARD_MAX_SIDE,
  MAX_FILE_BYTES,
  SIGNATURE_EXT,
  SIGNATURE_MIME,
} from "@/lib/guard/constants";

export type Kind = "photo" | "signature";

export type ValidateOk = {
  ok: true;
  mime: string;
  ext: string;
  format: string;
};

export type ValidateErr = { ok: false; message: string };
export type ValidateResult = ValidateOk | ValidateErr;

const MAGIC: Array<{ format: string; mime: string; test: (b: Uint8Array) => boolean }> = [
  {
    format: "jpeg",
    mime: "image/jpeg",
    test: (b) => b.length > 2 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  },
  {
    format: "png",
    mime: "image/png",
    test: (b) =>
      b.length > 7 &&
      b[0] === 0x89 &&
      b[1] === 0x50 &&
      b[2] === 0x4e &&
      b[3] === 0x47 &&
      b[4] === 0x0d &&
      b[5] === 0x0a &&
      b[6] === 0x1a &&
      b[7] === 0x0a,
  },
  {
    format: "webp",
    mime: "image/webp",
    test: (b) =>
      b.length > 11 &&
      ascii(b, 0, 4) === "RIFF" &&
      ascii(b, 8, 4) === "WEBP",
  },
  {
    format: "bmp",
    mime: "image/bmp",
    test: (b) => b.length > 1 && b[0] === 0x42 && b[1] === 0x4d,
  },
  {
    format: "tiff",
    mime: "image/tiff",
    test: (b) =>
      b.length > 3 &&
      ((b[0] === 0x49 && b[1] === 0x49 && b[2] === 0x2a && b[3] === 0x00) ||
        (b[0] === 0x4d && b[1] === 0x4d && b[2] === 0x00 && b[3] === 0x2a)),
  },
  {
    format: "heic",
    mime: "image/heic",
    test: (b) => isHeicLike(b),
  },
];

function ascii(b: Uint8Array, start: number, len: number): string {
  return String.fromCharCode(...b.slice(start, start + len));
}

function isHeicLike(b: Uint8Array): boolean {
  if (b.length < 16) return false;
  if (ascii(b, 4, 4) !== "ftyp") return false;
  const brand = ascii(b, 8, 4).toLowerCase();
  const brands = ["heic", "heix", "heif", "mif1", "msf1", "hevc", "avif"];
  if (brands.includes(brand) && brand !== "avif") return true;
  for (let i = 16; i + 4 <= Math.min(b.length, 64); i += 4) {
    const extra = ascii(b, i, 4).toLowerCase();
    if (extra === "heic" || extra === "heif" || extra === "mif1") return true;
  }
  return false;
}

function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}

export async function sniffFile(file: File, kind: Kind): Promise<ValidateResult> {
  if (!file || file.size === 0) {
    return { ok: false, message: "Choose an image to continue." };
  }
  if (file.size > MAX_FILE_BYTES) {
    return {
      ok: false,
      message: "That file is too large. Maximum size is 10 MB.",
    };
  }

  const ext = extOf(file.name);
  const allowedExt = kind === "signature" ? SIGNATURE_EXT : BG_EXT;
  const allowedMime = kind === "signature" ? SIGNATURE_MIME : BG_MIME;

  if (ext && !allowedExt.has(ext)) {
    return {
      ok: false,
      message:
        kind === "signature"
          ? "Signatures must be a transparent PNG."
          : `“.${ext}” isn’t a supported image. Use JPEG, PNG, WEBP, HEIC, BMP, or TIFF.`,
    };
  }

  if (file.type && file.type !== "application/octet-stream" && !allowedMime.has(file.type.toLowerCase())) {
    return {
      ok: false,
      message:
        kind === "signature"
          ? "Signatures must be a transparent PNG."
          : "That file isn’t a supported image type.",
    };
  }

  const head = new Uint8Array(await file.slice(0, 64).arrayBuffer());
  const magic = MAGIC.find((m) => m.test(head));
  if (!magic) {
    return {
      ok: false,
      message:
        kind === "signature"
          ? "That file is not a real PNG. Signatures must be transparent PNG files."
          : "That file is not a real image. Rename tricks are rejected.",
    };
  }

  if (kind === "signature" && magic.format !== "png") {
    return {
      ok: false,
      message: "Signatures must be a transparent PNG.",
    };
  }

  if (kind === "photo" && !["jpeg", "png", "webp", "bmp", "tiff", "heic"].includes(magic.format)) {
    return { ok: false, message: "That file isn’t a supported image type." };
  }

  return { ok: true, mime: magic.mime, ext, format: magic.format };
}

export function dimensionError(width: number, height: number): string | null {
  if (width < 2 || height < 2) return "Image is too small to process.";
  const pixels = width * height;
  if (width > HARD_MAX_SIDE || height > HARD_MAX_SIDE || pixels > HARD_MAX_PIXELS) {
    return "Image is too large to process in the browser. Try a smaller photo.";
  }
  return null;
}
