import { hexToRgb } from "./detect-color";

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.min(1, Math.max(0, (x - edge0) / Math.max(1e-6, edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

function isAchromatic(r: number, g: number, b: number): boolean {
  return Math.max(r, g, b) - Math.min(r, g, b) < 28;
}

/**
 * Recolor ink while keeping original alpha (anti-aliased edges stay smooth).
 * Near-black sources also match gray anti-aliased fringe pixels.
 */
export function recolorImageData(
  source: ImageData,
  fromHex: string,
  toHex: string,
  tolerance: number,
): ImageData {
  const from = hexToRgb(fromHex);
  const to = hexToRgb(toHex);
  const out = new ImageData(source.width, source.height);
  const s = source.data;
  const d = out.data;
  const maxDist = Math.sqrt(3 * 255 * 255);
  const thresh = (Math.min(100, Math.max(0, tolerance)) / 100) * maxDist;
  const feather = Math.max(12, thresh * 0.4);
  const fromLum = 0.2126 * from.r + 0.7152 * from.g + 0.0722 * from.b;
  const fromIsDark = fromLum < 40;

  for (let i = 0; i < s.length; i += 4) {
    const r = s[i];
    const g = s[i + 1];
    const b = s[i + 2];
    const a = s[i + 3];
    d[i] = r;
    d[i + 1] = g;
    d[i + 2] = b;
    d[i + 3] = a;
    if (a === 0) continue;

    const dist = Math.hypot(r - from.r, g - from.g, b - from.b);
    let closeness = 1 - smoothstep(thresh - feather, thresh + feather, dist);

    if (fromIsDark && isAchromatic(r, g, b)) {
      closeness = Math.max(closeness, 0.85);
    }

    if (closeness <= 0.01) continue;

    d[i] = Math.round(r + (to.r - r) * closeness);
    d[i + 1] = Math.round(g + (to.g - g) * closeness);
    d[i + 2] = Math.round(b + (to.b - b) * closeness);
  }

  return out;
}

export function applyRecolor(
  canvas: HTMLCanvasElement,
  fromHex: string,
  toHex: string,
  tolerance: number,
): HTMLCanvasElement {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Could not recolor this image.");
  const src = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const next = recolorImageData(src, fromHex, toHex, tolerance);
  const out = document.createElement("canvas");
  out.width = canvas.width;
  out.height = canvas.height;
  const octx = out.getContext("2d");
  if (!octx) throw new Error("Could not recolor this image.");
  octx.putImageData(next, 0, 0);
  return out;
}
