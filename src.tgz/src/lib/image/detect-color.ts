export type Rgb = { r: number; g: number; b: number };

export function hexToRgb(hex: string): Rgb {
  const h = hex.replace("#", "").trim();
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = Number.parseInt(full, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export function rgbToHex({ r, g, b }: Rgb): string {
  const to = (v: number) => v.toString(16).padStart(2, "0");
  return `#${to(r)}${to(g)}${to(b)}`.toUpperCase();
}

export function detectDominantColor(canvas: HTMLCanvasElement): string {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return "#000000";
  const { data, width, height } = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const buckets = new Map<number, number>();
  const step = Math.max(1, Math.floor(Math.sqrt(width * height) / 180));

  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      const a = data[i + 3];
      if (a < 24) continue;
      const r = data[i] >> 3;
      const g = data[i + 1] >> 3;
      const b = data[i + 2] >> 3;
      const key = (r << 10) | (g << 5) | b;
      buckets.set(key, (buckets.get(key) ?? 0) + a);
    }
  }

  let bestKey = 0;
  let best = 0;
  for (const [key, weight] of buckets) {
    const r = (key >> 10) & 31;
    const g = (key >> 5) & 31;
    const b = key & 31;
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    // Skip near-white paper leftovers
    if (lum > 28 && r > 26 && g > 26 && b > 26) continue;
    if (weight > best) {
      best = weight;
      bestKey = key;
    }
  }

  if (best === 0) return "#000000";
  const r = Math.min(255, ((bestKey >> 10) & 31) * 8 + 4);
  const g = Math.min(255, ((bestKey >> 5) & 31) * 8 + 4);
  const b = Math.min(255, (bestKey & 31) * 8 + 4);
  return rgbToHex({ r, g, b });
}
