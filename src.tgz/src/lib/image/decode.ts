import { MAX_DIMENSION } from "@/lib/guard/constants";
import { dimensionError } from "./validate";

export type DecodedImage = {
  bitmap: ImageBitmap;
  width: number;
  height: number;
  originalWidth: number;
  originalHeight: number;
  resized: boolean;
  canvas: HTMLCanvasElement;
};

async function canvasFromBitmap(
  bitmap: ImageBitmap,
  width: number,
  height: number,
): Promise<HTMLCanvasElement> {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Could not read this image.");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bitmap, 0, 0, width, height);
  return canvas;
}

function fitSize(width: number, height: number, maxSide: number): { width: number; height: number; scale: number } {
  const scale = Math.min(1, maxSide / Math.max(width, height));
  if (scale >= 1) return { width, height, scale: 1 };
  return {
    width: Math.max(2, Math.round(width * scale)),
    height: Math.max(2, Math.round(height * scale)),
    scale,
  };
}

async function decodeTiff(blob: Blob): Promise<ImageBitmap> {
  const UTIF = await import("utif");
  const buf = new Uint8Array(await blob.arrayBuffer());
  const ifds = UTIF.decode(buf);
  if (!ifds[0]) throw new Error("Could not read this TIFF.");
  UTIF.decodeImage(buf, ifds[0]);
  const rgba = UTIF.toRGBA8(ifds[0]);
  const width = ifds[0].width || ifds[0].t256?.[0] || 0;
  const height = ifds[0].height || ifds[0].t257?.[0] || 0;
  if (!width || !height) throw new Error("Could not read this TIFF.");
  const imageData = new ImageData(new Uint8ClampedArray(rgba), width, height);
  return createImageBitmap(imageData);
}

async function decodeHeic(blob: Blob): Promise<ImageBitmap> {
  const { heicTo } = await import("heic-to");
  return heicTo({
    blob,
    type: "bitmap",
    options: { imageOrientation: "from-image" },
  });
}

export async function decodeImage(file: File, format: string): Promise<DecodedImage> {
  let bitmap: ImageBitmap;
  try {
    if (format === "tiff") {
      bitmap = await decodeTiff(file);
    } else if (format === "heic") {
      try {
        bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
      } catch {
        bitmap = await decodeHeic(file);
      }
    } else {
      bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
    }
  } catch {
    throw new Error("Could not read this image. It may be damaged or unsupported.");
  }

  const originalWidth = bitmap.width;
  const originalHeight = bitmap.height;
  const dim = dimensionError(originalWidth, originalHeight);
  if (dim) {
    bitmap.close();
    throw new Error(dim);
  }

  const fitted = fitSize(originalWidth, originalHeight, MAX_DIMENSION);
  const canvas = await canvasFromBitmap(bitmap, fitted.width, fitted.height);
  return {
    bitmap,
    width: fitted.width,
    height: fitted.height,
    originalWidth,
    originalHeight,
    resized: fitted.scale < 1,
    canvas,
  };
}

export function canvasHasTransparency(canvas: HTMLCanvasElement): boolean {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return false;
  const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);
  for (let i = 3; i < data.length; i += 4) {
    if (data[i] < 250) return true;
  }
  return false;
}

export function canvasToBlob(
  canvas: HTMLCanvasElement,
  type = "image/png",
  quality?: number,
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) reject(new Error("Could not encode image."));
        else resolve(blob);
      },
      type,
      quality,
    );
  });
}

export function canvasToPngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return canvasToBlob(canvas, "image/png");
}
