export type CropResult = {
  canvas: HTMLCanvasElement;
  cropped: boolean;
  fromWidth: number;
  fromHeight: number;
  toWidth: number;
  toHeight: number;
};

type Bounds = { minX: number; minY: number; maxX: number; maxY: number };

function inkBounds(data: Uint8ClampedArray, width: number, height: number, alphaMin: number): Bounds | null {
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;

  for (let y = 0; y < height; y++) {
    const row = y * width;
    for (let x = 0; x < width; x++) {
      if (data[(row + x) * 4 + 3] <= alphaMin) continue;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  }

  if (maxX < 0) return null;
  return { minX, minY, maxX, maxY };
}

/**
 * Tight-crop a transparent signature to its ink, with a little padding so
 * anti-aliased edges are not clipped.
 */
export function cropToInk(
  source: HTMLCanvasElement,
  opts?: { paddingRatio?: number; alphaMin?: number },
): CropResult {
  const fromWidth = source.width;
  const fromHeight = source.height;
  const ctx = source.getContext("2d", { willReadFrequently: true });
  if (!ctx) {
    return {
      canvas: source,
      cropped: false,
      fromWidth,
      fromHeight,
      toWidth: fromWidth,
      toHeight: fromHeight,
    };
  }

  const { data } = ctx.getImageData(0, 0, fromWidth, fromHeight);
  const bounds = inkBounds(data, fromWidth, fromHeight, opts?.alphaMin ?? 10);
  if (!bounds) {
    throw new Error("No signature ink found. Use a PNG with visible strokes and a transparent background.");
  }

  const inkW = bounds.maxX - bounds.minX + 1;
  const inkH = bounds.maxY - bounds.minY + 1;
  const ratio = opts?.paddingRatio ?? 0.06;
  const pad = Math.max(8, Math.round(Math.max(inkW, inkH) * ratio));

  const x = Math.max(0, bounds.minX - pad);
  const y = Math.max(0, bounds.minY - pad);
  const toWidth = Math.min(fromWidth - x, inkW + pad * 2);
  const toHeight = Math.min(fromHeight - y, inkH + pad * 2);

  const saved = 1 - (toWidth * toHeight) / Math.max(1, fromWidth * fromHeight);
  if (saved < 0.04) {
    return {
      canvas: source,
      cropped: false,
      fromWidth,
      fromHeight,
      toWidth: fromWidth,
      toHeight: fromHeight,
    };
  }

  const canvas = document.createElement("canvas");
  canvas.width = toWidth;
  canvas.height = toHeight;
  const out = canvas.getContext("2d");
  if (!out) throw new Error("Could not crop this signature.");
  out.drawImage(source, x, y, toWidth, toHeight, 0, 0, toWidth, toHeight);

  return {
    canvas,
    cropped: true,
    fromWidth,
    fromHeight,
    toWidth,
    toHeight,
  };
}
