export type ProgressFn = (label: string, ratio: number) => void;

let preloading: Promise<void> | null = null;

function friendlyProgress(key: string): string {
  const k = key.toLowerCase();
  if (k.includes("fetch") || k.includes("download") || k.includes("wasm") || k.includes("model")) {
    return "Downloading the on-device model";
  }
  if (k.includes("compute") || k.includes("infer") || k.includes("session")) {
    return "Cutting the subject";
  }
  return "Working";
}

export async function preloadBackgroundModel(onProgress?: ProgressFn): Promise<void> {
  if (!preloading) {
    preloading = (async () => {
      const { preload } = await import("@imgly/background-removal");
      await preload({
        model: "isnet_fp16",
        output: { format: "image/png", quality: 1 },
        progress: (key, current, total) => {
          const ratio = total > 0 ? current / total : 0;
          onProgress?.(friendlyProgress(key), ratio);
        },
      });
    })().catch((err) => {
      preloading = null;
      throw err;
    });
  }
  return preloading;
}

export async function removeBackgroundBlob(
  source: Blob,
  onProgress?: ProgressFn,
): Promise<Blob> {
  const { removeBackground } = await import("@imgly/background-removal");
  const blob = await removeBackground(source, {
    model: "isnet_fp16",
    output: { format: "image/png", quality: 1 },
    progress: (key, current, total) => {
      const ratio = total > 0 ? current / total : 0;
      onProgress?.(friendlyProgress(key), ratio);
    },
  });
  return blob;
}
