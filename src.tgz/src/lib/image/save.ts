function isAppleTouch(): boolean {
  if (typeof navigator === "undefined") return false;
  return (
    /iP(hone|ad|od)/.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
  );
}

async function asPngFile(blob: Blob, filename: string): Promise<File> {
  const type = blob.type || "";
  if (type.startsWith("image/")) {
    return blob instanceof File ? blob : new File([blob], filename, { type });
  }
  const buf = await blob.arrayBuffer();
  return new File([buf], filename, { type: "image/png" });
}

/**
 * Save a PNG on desktop and iPhone. iOS ignores <a download> for blob URLs,
 * and a same-frame click can navigate the preview away — never do that.
 */
export async function savePng(blob: Blob, filename: string): Promise<"shared" | "downloaded" | "opened"> {
  const file = await asPngFile(blob, filename);

  if (typeof navigator !== "undefined" && navigator.share && navigator.canShare) {
    try {
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: filename });
        return "shared";
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return "shared";
    }
  }

  const url = URL.createObjectURL(file);
  const apple = isAppleTouch();

  if (apple) {
    const opened = window.open(url, "_blank", "noopener");
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    if (!opened) throw new Error("HOLD_TO_SAVE");
    return "opened";
  }

  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 15_000);
  return "downloaded";
}

export { isAppleTouch };
