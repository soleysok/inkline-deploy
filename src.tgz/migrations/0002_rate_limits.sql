-- Anonymous abuse-protection counters. IPs are stored as HMAC hashes, never raw.
create table if not exists rate_windows (
  ip_hash text not null,
  job_type text not null,
  window_start bigint not null,
  count integer not null default 0,
  last_success_at bigint,
  primary key (ip_hash, job_type, window_start)
);

create index if not exists rate_windows_window_idx on rate_windows (window_start);

create table if not exists used_nonces (
  nonce text primary key,
  expires_at bigint not null
);

create table if not exists ip_cooldown (
  ip_hash text primary key,
  last_success_at bigint not null
);
